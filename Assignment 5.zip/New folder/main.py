import maths_utils
from maths_utils import square
import string_utils
import shop_package.discount as disc
from shop_package.billing import calculate_total




print(maths_utils.add(4,5))
print(maths_utils.subtract(10,7))
print(square(4))
print("\n")

print(string_utils.capitalze_words("Hello"))
print(string_utils.reverse_string("Hello"))
print(string_utils.word_count("Hello"))
print("\n")

print(disc.apply_discount(1000,10))
print(calculate_total([100,200,300]))